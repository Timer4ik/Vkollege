

class AuthController {
   async login(req,res){

   }

   async register(req,res){
      
   }
}

module.exports = new AuthController()