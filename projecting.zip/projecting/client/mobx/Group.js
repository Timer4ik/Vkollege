import { makeAutoObservable } from "mobx"

class Group {

    constructor() {
        makeAutoObservable(this)
    }
}