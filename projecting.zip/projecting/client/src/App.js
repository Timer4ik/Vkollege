
function App() {
   return (
      <div className="App">
         <header>
            <nav>
               <ul>
                  <li>Специальности</li>
                  <li>Группы</li>
                  <li>Преподаватели</li>
                  <li>Студенты</li>
               </ul>
            </nav>
         </header>
         <main>
            <p>ФИЩИ</p>
         </main>
         <footer>
            
         </footer>
      </div>
   )
}

export default App
